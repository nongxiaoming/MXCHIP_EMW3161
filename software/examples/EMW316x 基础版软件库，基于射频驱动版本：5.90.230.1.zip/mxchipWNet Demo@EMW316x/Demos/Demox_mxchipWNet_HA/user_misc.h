#include "stm32f2xx.h"


u16 calc_sum(void *data, u32 len);


int check_sum(void *data, u32 len);

